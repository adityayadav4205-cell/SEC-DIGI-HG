# SEC-Digital — corrected deployment baseline

This version fixes the deployment architecture around **Next.js + Vercel + Supabase PostgreSQL + Prisma + Capacitor**.

## 1. Architecture

```text
Android Capacitor app
        |
        v
HTTPS -> Vercel production URL
        |
        v
Next.js API routes
        |
        v
Prisma
        |
        v
Supabase PostgreSQL
```

Supabase is used as the PostgreSQL host. The application authentication remains server-side and uses an HTTP-only signed session cookie. No database password or service key is exposed to the browser.

## 2. Supabase setup

In Supabase Dashboard:

1. Open **Connect**.
2. Copy the **Transaction pooler** URL for runtime use and put it in `DATABASE_URL`.
3. Copy the **Direct connection** URL for Prisma CLI use and put it in `DIRECT_URL`.
4. Replace the password safely; URL-encode reserved password characters.
5. Apply the Prisma schema with `npx prisma db push` or your migration workflow.

For serverless deployment, Supabase/Prisma recommend separating the pooled runtime connection from the direct CLI connection.

## 3. Vercel environment variables

Add these under **Vercel → Project → Settings → Environment Variables → Production**:

```text
DATABASE_URL=your Supabase transaction-pooler URL
DIRECT_URL=your Supabase direct URL
SEC_AUTH_SECRET=a random secret of at least 32 characters
```

After changing variables, redeploy the production deployment.

Do not commit `.env` or database passwords to GitHub.

## 4. First local setup

```bash
cp .env.example .env
npm install
npx prisma generate
npx prisma db push
npm run dev
```

Open `http://localhost:3000`.

You need at least one Branch and User record in Supabase before login can work. Passwords must be stored as bcrypt hashes.

## 5. Production deploy

Connect this repository to Vercel and set the three production variables above. Set the main branch as the Production Branch. Deploy.

Use your permanent production URL, for example:

```text
https://sec-digital.vercel.app
```

Do not hard-code a temporary Vercel preview deployment into the APK.

## 6. Android APK

Set a GitHub repository variable:

```text
CAPACITOR_SERVER_URL=https://YOUR-PRODUCTION-DOMAIN
```

The included GitHub Action then:

1. installs dependencies
2. generates Prisma Client
3. creates the Android Capacitor project
4. syncs Capacitor
5. builds `app-debug.apk`
6. uploads the APK as a GitHub Actions artifact

For a release APK/AAB, add Android signing secrets and a separate release workflow.

## 7. Important security changes

- Removed the `CHANGE_ME_BEFORE_PRODUCTION` authentication fallback.
- Removed token storage in browser `localStorage`.
- Login now sets an HTTP-only, Secure production cookie.
- Added `/api/me` and `/api/auth/logout`.
- Added strict environment preflight checks.
- Removed the old Vercel deployment URL.
- Removed duplicate root files that could create confusing Next.js route resolution.

## 8. What is not included yet

The original project has navigation labels for Sessions, POS, Bills, Bookings, Inventory, Expenses, Attendance and Reports, but those screens are not fully implemented in the source that was supplied. This corrected package fixes the **deployment/auth/database/mobile foundation**; it does not pretend those business modules are already complete.
