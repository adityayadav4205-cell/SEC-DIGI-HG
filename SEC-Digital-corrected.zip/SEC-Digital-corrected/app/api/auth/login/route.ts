import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { setSession, signToken } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (!email || !password) return Response.json({ error: "Email and password are required" }, { status: 400 });

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !user.active || !(await bcrypt.compare(password, user.passwordHash))) {
      return Response.json({ error: "Invalid email or password" }, { status: 401 });
    }

    const token = signToken({ id: user.id, branchId: user.branchId, role: user.role, name: user.name });
    await setSession(token);
    return Response.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    console.error("login", error);
    return Response.json({ error: "Unable to sign in" }, { status: 500 });
  }
}
