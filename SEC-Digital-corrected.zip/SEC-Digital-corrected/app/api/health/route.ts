import { prisma } from "@/lib/prisma";
export async function GET() {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return Response.json({ ok: true, service: "SEC-Digital", database: "reachable", time: new Date().toISOString() });
  } catch (error) {
    console.error("health", error);
    return Response.json({ ok: false, service: "SEC-Digital", database: "unreachable" }, { status: 503 });
  }
}
