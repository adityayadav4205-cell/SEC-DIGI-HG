import "./style.css";
export const metadata={title:"SEC-Digital",description:"Student Entertainment Club Management"};
export default function Layout({children}:{children:React.ReactNode}){return <html><body>{children}</body></html>}
