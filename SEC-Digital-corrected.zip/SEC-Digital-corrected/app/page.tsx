"use client";
import { useEffect, useState } from "react";

type User = { id: string; name: string; email: string; role: string };
const modules = ["Dashboard", "Sessions", "POS", "Bills", "Bookings", "Inventory", "Expenses", "Attendance", "Reports"];

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [notice, setNotice] = useState("");
  const [health, setHealth] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/me").then(r => r.ok ? r.json() : null).then(x => x?.user && setUser(x.user)).catch(() => {});
  }, []);

  async function login(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setNotice("");
    try {
      const r = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
      const j = await r.json(); if (!r.ok) throw new Error(j.error || "Sign in failed");
      setUser(j.user); setNotice(`Welcome ${j.user.name}`);
    } catch (e: any) { setNotice(e.message); } finally { setBusy(false); }
  }

  async function logout() { await fetch("/api/auth/logout", { method: "POST" }); setUser(null); }
  async function check() { setHealth(null); const r = await fetch("/api/health"); setHealth(await r.json()); }

  if (!user) return <main className="login"><section className="loginCard"><div className="brand">SEC<span>Digital</span></div><p>Student Entertainment Club Management</p><form onSubmit={login}><input autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email"/><input autoComplete="current-password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password"/><button disabled={busy}>{busy ? "Signing in…" : "Sign In"}</button></form>{notice && <p className="notice">{notice}</p>}</section></main>;

  return <main className="app"><header><div><div className="brand">SEC<span>Digital</span></div><small>{user.name} • {user.role}</small></div><button className="ghost" onClick={logout}>Logout</button></header><nav>{modules.map((m, i) => <button key={m} className={i === 0 ? "active" : ""}>{m}</button>)}</nav><section><h2>Dashboard</h2><div className="grid"><div className="card"><small>Backend</small><strong>{health?.ok ? "Online" : "Not checked"}</strong><button onClick={check}>Check backend</button></div><div className="card"><small>Role</small><strong>{user.role}</strong></div><div className="card"><small>Authentication</small><strong>Secure cookie</strong></div></div>{notice && <p className="notice">{notice}</p>}{health && <pre>{JSON.stringify(health, null, 2)}</pre>}</section></main>;
}
