import type { CapacitorConfig } from "@capacitor/cli";

const productionUrl = process.env.CAPACITOR_SERVER_URL || "https://sec-digital.vercel.app";

const config: CapacitorConfig = {
  appId: "com.secdigital.app",
  appName: "SEC-Digital",
  webDir: "public",
  server: {
    url: productionUrl,
    androidScheme: "https",
    cleartext: false
  }
};
export default config;
