import crypto from "crypto";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";

const COOKIE = "sec_session";
const TTL = 1000 * 60 * 60 * 12;

function secret() {
  const value = process.env.SEC_AUTH_SECRET;
  if (!value || value.length < 32) throw new Error("SEC_AUTH_SECRET is not configured correctly");
  return value;
}

type SessionPayload = { id: string; branchId: string; role: string; name: string; exp: number };

export function signToken(payload: Omit<SessionPayload, "exp">) {
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + TTL })).toString("base64url");
  const sig = crypto.createHmac("sha256", secret()).update(body).digest("base64url");
  return `${body}.${sig}`;
}

export function verifyToken(token: string | undefined): SessionPayload | null {
  try {
    if (!token) return null;
    const [body, sig] = token.split(".");
    if (!body || !sig) return null;
    const expected = crypto.createHmac("sha256", secret()).update(body).digest("base64url");
    if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const user = JSON.parse(Buffer.from(body, "base64url").toString()) as SessionPayload;
    return user.exp > Date.now() ? user : null;
  } catch {
    return null;
  }
}

export async function setSession(token: string) {
  const jar = await cookies();
  jar.set(COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 60 * 60 * 12 });
}

export async function clearSession() {
  const jar = await cookies();
  jar.set(COOKIE, "", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 0 });
}

export async function getCurrentUser() {
  const jar = await cookies();
  const tokenUser = verifyToken(jar.get(COOKIE)?.value);
  if (!tokenUser) return null;
  const user = await prisma.user.findUnique({ where: { id: tokenUser.id } });
  if (!user || !user.active || user.branchId !== tokenUser.branchId) return null;
  return { id: user.id, branchId: user.branchId, role: user.role, name: user.name, email: user.email };
}
