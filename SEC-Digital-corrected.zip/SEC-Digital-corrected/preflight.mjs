import fs from "fs";
const required=["package.json","prisma/schema.production.prisma","app/page.tsx","app/layout.tsx","lib/prisma.ts"];
let fail=false;for(const f of required){if(fs.existsSync(f))console.log("OK:",f);else{console.error("MISSING:",f);fail=true;}}
const schema=fs.readFileSync("prisma/schema.production.prisma","utf8");if(!schema.includes('provider = "postgresql"')){console.error("Production schema is not PostgreSQL");fail=true;}
if(fail)process.exit(1);console.log("SEC-Digital production preflight passed.");
