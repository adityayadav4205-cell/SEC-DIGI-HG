const required = ["DATABASE_URL", "DIRECT_URL", "SEC_AUTH_SECRET"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) { console.error(`Missing environment variables: ${missing.join(", ")}`); process.exit(1); }
if (process.env.SEC_AUTH_SECRET.length < 32) { console.error("SEC_AUTH_SECRET must be at least 32 characters"); process.exit(1); }
if (process.env.DATABASE_URL.includes("YOUR-") || process.env.DIRECT_URL.includes("YOUR-")) { console.error("Database URLs still contain placeholders"); process.exit(1); }
console.log("Preflight OK");
