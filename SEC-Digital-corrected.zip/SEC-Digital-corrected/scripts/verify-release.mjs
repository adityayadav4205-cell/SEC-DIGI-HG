import fs from "node:fs";
const bad = ["CHANGE_ME_BEFORE_PRODUCTION", "localhost", "sec-digital-kv1i3y8ol-adityayadav4205-cell.vercel.app"];
const files = ["capacitor.config.ts", "lib/auth.ts", ".env.example"];
for (const f of files) {
  const text = fs.readFileSync(f, "utf8");
  for (const s of bad) if (text.includes(s) && s !== "localhost") throw new Error(`${f} contains release placeholder/old URL: ${s}`);
}
console.log("Release verification OK");
